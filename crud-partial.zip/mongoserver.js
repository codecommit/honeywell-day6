let express = require("express");
let mongoose = require("mongoose");// ORM
let bodyparser = require("body-parser");
let cors = require("cors");


let app = express();
let heroRoutes = express.Router();

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
var Hero = mongoose.model("Hero", new Schema({
    id:ObjectId,
    title:String,
    city:String,
    power:Number
}));

mongoose.Promise = global.Promise;
 mongoose.connect("mongodb://honeywelluser:honeywell123@ds145183.mlab.com:45183/honeywelldb", { useNewUrlParser: true }).then(
// mongoose.connect("mongodb://localhost:27017/honeywelldb", { useNewUrlParser: true }).then(
    () => { console.log("DB Connected")},
    (error) => {console.log("Error ", error)}
);
//MIDDLEWARES---------------------------
app.use(bodyparser.json());
app.use(cors());
app.use("/heroes", heroRoutes);

// READ
heroRoutes.route("/").get(function(reqest, response){
      Hero.find(function(error, heroes){
        if(error){
            console.log("Error : ", error)
        }else{
            response.send(heroes); 
        }
    })
});

// CREATE
heroRoutes.route("/add").post(function(req, res){
    let hero = new Hero(req.body);
    console.log(req.body);
    hero.save().then(function(){
       // res.send("hero added");
       res.status(200).json({'hero':'Hero added successfully'});
    }, function(error){
        res.status(400).send("Unable to save the hero in database")
    })
})

// EDIT
heroRoutes.route("/edit/:id").get(function(req, res){
    console.log("update requested");
    let heroId = req.param.id;
    Hero.findById(heroId, function(error, hero){
        if(error){
            console.log("unable to find hero by that id")
        }else{
            res.json(hero);
        }
    })
});


// DELETE
heroRoutes.route("/delete/:id").get(function(req, res){
    console.log("delete request");
    Hero.findByIdAndRemove({_id: req.param.id}, function(error, hero){
        if(error){
            res.json(error)
        }else{
            res.send("Hero deleted")
        }
    })
})

// UPDATE

heroRoutes.route("/update/:id").post(function(req, res){
    console.log(req.param.id);
    Hero.findById(req.param.id, function(err, hero){
        if(!hero){
            console.log("Error", error)
        }else{
            hero.title = req.body.title;
            hero.city = req.body.city;
            hero.power = req.body.power;
            hero.save().then(() => {
                res.json(hero);
            }).catch(error => {
                console.log("Error :", error)
            })
        }
    })
});



//--------------------------------------

app.listen(2525, function(error){
    if(error){
        console.log(error)
    }else{
        console.log("web server is now live on localhost:2525")
    }
});