import { Component, OnInit } from "@angular/core";
import { HeroServices } from "./hero.service";
import { FormGroup, Validators, FormBuilder } from "@angular/forms";

@Component({
    template : `
    Welcome to add component
    <div class="panel panel-default">
    <div class="panel-heading">
      {{ appTitle }}
    </div>
    <div class="panel-body">
      <form [formGroup]="angForm" novalidate>
        <div class="form-group">
          <label class="col-md-4">Hero Name</label>
          <input type="text" class="form-control" formControlName="title" #title />
        </div>
        <div *ngIf="angForm.controls['title'].invalid && (angForm.controls['title'].dirty || angForm.controls['title'].touched)" class="alert alert-danger">
          <div *ngIf="angForm.controls['title'].errors.required"> Title is required. </div>
        </div>
        <div class="form-group">
          <label class="col-md-4">Hero City</label>
          <input type="text" class="form-control" formControlName="city" #city />
        </div>
        <div *ngIf="angForm.controls['city'].invalid && (angForm.controls['city'].dirty || angForm.controls['city'].touched)" class="alert alert-danger">
          <div *ngIf="angForm.controls['city'].errors.required"> City is required. </div>
        </div>
        <div class="form-group">
          <label class="col-md-4">Hero Power: <span #log></span></label>
          <input type="range" min="0" max="10" class="form-control" (input)="log.innerHTML = power.value"  formControlName="power" #power/>
        </div>
        <div *ngIf="angForm.controls['power'].invalid && (angForm.controls['power'].dirty || angForm.controls['power'].touched)" class="alert alert-danger">
          <div *ngIf="angForm.controls['power'].errors.required">
            Power is required.
          </div>
        </div>
          <div class="form-group">
            <button type="button" (click)="addHero(title.value, city.value, power.value )" [disabled]="angForm.pristine || angForm.invalid" class="btn btn-primary">Add</button>
          </div>
      </form>
    </div>
  </div>
    `
})
export class AddComponent implements OnInit{
    appTitle = 'Add Heroes' ;
    angForm: FormGroup;

    constructor(private hs:HeroServices, private fb: FormBuilder){}
    ngOnInit(){
        this.angForm = this.fb.group({
            title: ['', Validators.required ],
            city: ['', Validators.required ],
            power: ['', Validators.required ]
         });
    }
    addHero(ht, hc, hp){
        this.hs.addHero(ht, hc, hp);
    }
}