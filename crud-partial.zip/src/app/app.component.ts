import { Component } from '@angular/core';
import { HeroServices } from './hero.service';

@Component({
  selector: 'app-root',
  template: `
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <ul class="nav navbar-nav">
        <li class="active">
          <a routerLink="add" routerLinkActive="active"> Add Heroes </a>
        </li>    
        <li class="active">
          <a routerLink="home" routerLinkActive="active"> Heroes List </a>
        </li> 
      </ul>
    </div>
  </nav>
  <div class="container">
    <router-outlet></router-outlet>
  </div>
  `

})
export class AppComponent {
  title = "Welcome to Honeywell Heroes App";
  // constructor(private hs: HeroServices) { }
}
