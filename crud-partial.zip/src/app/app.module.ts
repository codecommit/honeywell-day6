import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { appRouter } from './router.config';
import { HomeComponent } from './home.component';
import { AddComponent } from './add.component';
import { UpdateComponent } from './update.component';
import { HeroServices } from './hero.service';

@NgModule({
  declarations: [
    AppComponent, HomeComponent, AddComponent, UpdateComponent
  ],
  imports: [ BrowserModule, FormsModule, RouterModule.forRoot(appRouter), HttpClientModule, ReactiveFormsModule ],
  providers: [HeroServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
