import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class HeroServices{
    // uri = "http://localhost:2525/heroes/";
    constructor(private http:HttpClient){}

    getHeroes(){
        let uri = "http://localhost:2525/heroes/"
        return this.http.get(uri);
    }
    addHero(title, city, power){
        let uri = "http://localhost:2525/heroes/add"
        const heroObj = {
            title,
            city,
            power
        };
        this.http.post(uri, heroObj).subscribe( res => {
            console.log("hero added", res);
        });
    }
    editHero(id) {
        let uri = "http://localhost:2525/heroes/edit/"
        return this.http.get(uri+id);
    }
    updateHero(title, city, power, id){
        let uri = "http://localhost:2525/heroes/update/"
        const obj = {
          title:title,
          city : city,
          power : power
        };
        console.log('update request', id);
        this.http.post(uri + id, obj).subscribe(res => console.log(res));
     }
    deleteHero(id){
        let uri = "http://localhost:2525/heroes/delete/"
        return this.http.get(uri+id);
    }
}