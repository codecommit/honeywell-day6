import { Routes } from "@angular/router";
import { HomeComponent } from "./home.component";
import { AddComponent } from "./add.component";
import { UpdateComponent } from "./update.component";

export const appRouter:Routes = [
    { path : 'add', component : AddComponent  },
    { path : 'update/:id', component : UpdateComponent  },
    { path : 'home', component : HomeComponent  }
]