import { Component } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { HeroServices } from "./hero.service";

@Component({
    template : `
    <div class="panel panel-primary">
  <div class="panel-heading">
    {{ apptitle }}
  </div>
  <div class="panel-body">
    <form [formGroup]="angForm" novalidate>
      <div class="form-group">
        <label class="col-md-4">Hero Title</label>
        <input type="text" class="form-control" formControlName="title" #title [(ngModel)]="hero.title"/>
      </div>
      <div *ngIf="angForm.controls['title'].invalid && (angForm.controls['title'].dirty || angForm.controls['title'].touched)" class="alert alert-danger">
        <div *ngIf="angForm.controls['title'].errors.required"> Title is required. </div>
      </div>
      <div class="form-group">
        <label class="col-md-4">Hero City</label>
        <input type="text" class="form-control" formControlName="city" #city [(ngModel)]="hero.city"/>
      </div>
      <div *ngIf="angForm.controls['city'].invalid && (angForm.controls['city'].dirty || angForm.controls['city'].touched)" class="alert alert-danger">
        <div *ngIf="angForm.controls['city'].errors.required"> City is required. </div>
      </div>
      <div class="form-group">
        <label class="col-md-4">Hero Power : <span #log></span></label>
        <input type="range" min="0" max="10" (input)="log.innerHTML = power.value" class="form-control" formControlName="power" #power [(ngModel)] = "hero.power" />
        
      </div>
      <div *ngIf="angForm.controls['power'].invalid && (angForm.controls['power'].dirty || angForm.controls['power'].touched)" class="alert alert-danger">
        <div *ngIf="angForm.controls['power'].errors.required">
          Power is required.
        </div>
      </div>
        <div class="form-group">
          <button type="button" (click)="updateHero(title.value, power.value)" [disabled]="angForm.pristine || angForm.invalid" class="btn btn-primary">Update</button>
        </div>
    </form>
  </div>
</div>
    
    `
    
})
export class UpdateComponent{
    apptitle = 'Update Heroes';
    hero: any;
    angForm: FormGroup;

    constructor(private route: ActivatedRoute, private router: Router, private service: HeroServices, private fb: FormBuilder){
    }
    

    updateHero(title,city, power) {
        this.route.params.subscribe(params => {
         this.service.updateHero(title, city, power, this.route.snapshot.params['id']);
         // this.router.navigate(['home']);
         })
    };

    ngOnInit(){

        this.angForm = this.fb.group({
            title: ['', Validators.required ],
            city: ['', Validators.required ],
            power: ['', Validators.required ]
         });

        this.route.params.subscribe(params => {
          this.hero = this.service.editHero(params['id']).subscribe(res => {
            this.hero = res;
            console.log(this.hero);
          });
        });
      }

}