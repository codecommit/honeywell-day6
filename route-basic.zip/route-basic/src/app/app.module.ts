import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { HomeComp } from './home.component';
import { ProductComp } from './product.component';
import { ContactComponent } from './contact/contact.component';

@NgModule({
  declarations: [ AppComponent, HomeComp, ProductComp, ContactComponent ],
  imports: [ BrowserModule, RouterModule.forRoot([
    { path : 'home', component : HomeComp},
    { path : 'product', component : ProductComp}
  ], { useHash : true }) ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
