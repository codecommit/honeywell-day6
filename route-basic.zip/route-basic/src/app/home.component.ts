import { Component } from "@angular/core";

@Component({
    template : `
    <h1> Home component </h1>
    `
})
export class HomeComp{

}