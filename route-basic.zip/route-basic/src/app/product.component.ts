import { Component } from "@angular/core";

@Component({
    template : `
    <h1> Product component </h1>
    `
})
export class ProductComp{

}