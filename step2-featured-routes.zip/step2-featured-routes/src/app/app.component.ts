import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : ` 
  <h1>Main Component</h1>
  <a routerLink="/">Home</a> | 
  <a routerLink="hero">Hero</a> | 
  <a routerLink="addhero">Add Hero</a> | 
  <a routerLink="edithero">Edit Hero</a> | 
  <a routerLink="movies">Movie</a> | 
  <a routerLink="addmovie">Add Movie</a> | 
  <a routerLink="editmovie">Edit Movie</a> | 
  <hr>
  <router-outlet></router-outlet>
  `

})
export class AppComponent {
  title = 'step2-featured-routes';
}
