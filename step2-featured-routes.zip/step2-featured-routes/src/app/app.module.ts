import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome.component';
import { HeroesModule } from './heroes.module';
import { MoviesModule } from './movies.module';
 
@NgModule({
  declarations: [ AppComponent, WelcomeComponent  ],
  imports: [ BrowserModule, RouterModule.forRoot([
    { path : '', component : WelcomeComponent}
  ]), HeroesModule, MoviesModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
