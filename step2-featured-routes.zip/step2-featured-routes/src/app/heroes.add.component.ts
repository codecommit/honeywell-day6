import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroes.list',
  template: `
    <p>
      heroes add works!
    </p>
  `,
  styles: []
})
export class HeroesAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
