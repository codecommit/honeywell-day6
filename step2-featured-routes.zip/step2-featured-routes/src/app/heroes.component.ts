import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroes',
  template: `
    <p>
      heroes list works!
    </p>
  `,
  styles: []
})
export class HeroesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
