import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroes.edit',
  template: `
    <p>
      heroes edit works!
    </p>
  `,
  styles: []
})
export class HeroesEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
