import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { HeroesComponent } from "./heroes.component";
import { HeroesAddComponent } from "./heroes.add.component";
import { HeroesEditComponent } from "./heroes.edit.component";

const heroRoutes = [
    { path : "hero", component : HeroesComponent},
    { path : "addhero", component : HeroesAddComponent},
    { path : "edithero", component : HeroesEditComponent},
]

@NgModule({
    declarations : [HeroesComponent, HeroesAddComponent, HeroesEditComponent],
    imports : [RouterModule.forChild(heroRoutes)],
    exports : []
})
export class HeroesModule{}