import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movies.list',
  template: `
    <p>
      movies add works!
    </p>
  `,
  styles: []
})
export class MoviesAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
