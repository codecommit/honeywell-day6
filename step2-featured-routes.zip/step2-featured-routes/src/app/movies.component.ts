import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movies',
  template: `
    <p>
      movies list works!
    </p>
  `,
  styles: []
})
export class MoviesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
