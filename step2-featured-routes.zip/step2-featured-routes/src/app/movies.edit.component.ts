import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movies.edit',
  template: `
    <p>
      movies edit works!
    </p>
  `,
  styles: []
})
export class MoviesEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
