import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { MoviesComponent } from "./movies.component";
import { MoviesAddComponent } from "./movies.add.component";
import { MoviesEditComponent } from "./movies.edit.component";

const moviesRoute = [
    { path: "movies", component : MoviesComponent},
    { path: "addmovie", component : MoviesAddComponent},
    { path: "editmovie", component : MoviesEditComponent},
];

@NgModule({
    declarations : [MoviesComponent, MoviesAddComponent, MoviesEditComponent],
    imports : [RouterModule.forChild(moviesRoute)],
    exports : []    
})
export class MoviesModule{}