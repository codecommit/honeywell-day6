import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { ShowHeroesComp } from './show.heroes.component';
import { ShowHeroComp } from './show.hero.component';
import { EditHeroesComp } from './edit.heroes.component';
import { HeroService } from './hero.service';

const heroRoutes = [
   { path : "" , component : ShowHeroesComp },
   { path : "hero/:id" , component : ShowHeroComp, 
   children : [
     { path : "edit/:val", component: EditHeroesComp }
   ] },
];

@NgModule({
  declarations: [AppComponent, ShowHeroesComp, ShowHeroComp, EditHeroesComp ],
  imports: [ BrowserModule , RouterModule.forRoot(heroRoutes)],
  providers: [HeroService],
  bootstrap: [AppComponent]
})
export class AppModule { }
