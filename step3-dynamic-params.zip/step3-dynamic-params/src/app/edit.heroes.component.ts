import { Component } from "@angular/core";
import { HeroService } from "./hero.service";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <h1>Edit Hero</h1>
    <input [value]=heros[param-1].name />
    `
})
export class EditHeroesComp{
    heros = [];
    param = 0;

    constructor(private hs:HeroService, private ar:ActivatedRoute){}

    ngOnInit(){
        this.heros = this.hs.getHeroes();
        this.param = this.ar.snapshot.params['val'];
    }

}