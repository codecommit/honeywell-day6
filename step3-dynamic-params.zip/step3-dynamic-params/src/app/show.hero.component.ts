import { Component, OnInit } from "@angular/core";
import { HeroService } from "./hero.service";
import { ActivatedRoute } from "@angular/router";

@Component({
    template : `
    <h1>Hero</h1>
    <hr>
    <a [routerLink]="['']">Back to Home</a> | 
    <a [routerLink]="['edit', param]"> Edit The Hero </a>
    <h2>{{ heros[param-1].name }}</h2>
    
    <hr>
    <router-outlet></router-outlet>
    `
})
export class ShowHeroComp implements OnInit{
    heros = [];
    param = 0;

    constructor(private hs:HeroService, private ar:ActivatedRoute){}

    ngOnInit(){
        this.heros = this.hs.getHeroes();
        this.param = this.ar.snapshot.params['id'];
    }
}